# Code of Conduct

The Node.js Code of Conduct document has moved to
https://github.com/nodejs/TSC/blob/master/CODE_OF_CONDUCT.md. Please update
links to this document accordingly.
